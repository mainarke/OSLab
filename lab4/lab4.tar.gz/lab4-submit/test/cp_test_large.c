#include <linux/errno.h>
#include <sys/syscall.h>
#include <linux/unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define __NR_cp_range 287
_syscall2(long,cp_range,unsigned long *,arg1,unsigned long *,arg2);

#define PAGENUM 5
int main() {
    int i;
    char *p;
    unsigned long start, end;
    
    p = malloc(sizeof(char)*PAGENUM*4096);
    //start = (unsigned long) p;
    //end = start + (PAGENUM * 4096) - 1;
    start = 0;//(unsigned long) p;
    end = 0xbfffffff;//start + (PAGENUM * 4096) - 1;
    
    for (i=0; i < PAGENUM*4096; i++)
        p[i] = '0';
    cp_range(&start, &end);
    printf("cp0 finished\n");
    
    cp_range(&start, &end);
    printf("cp1 finished\n");
    
    free(p);
    return 0;
}
